require('dotenv').config({ path: require('path').join(__dirname, '.env') });

const express = require('express');
const cors = require('cors');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

// ========== Базовые middleware ==========
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// ========== Статика ==========
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));
// если папка uploads лежит внутри backend, замени на:
// app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// ========== Роуты ==========
app.use('/api/auth', require('./routes/auth'));
app.use('/api/requests', require('./routes/requests'));   // после переименования
app.use('/api/photos', require('./routes/photos'));       // после переименования
app.use('/api/analytics', require('./routes/analytics')); // после переименования

// ========== Health check ==========
app.get('/api/health', (req, res) => {
  res.json({ status: 'healthy', uptime: process.uptime() });
});

// ========== Глобальный обработчик ошибок ==========
app.use((err, req, res, next) => {
  console.error('❌ Error:', err.stack);
  res.status(err.status || 500).json({
    success: false,
    error: {
      message: err.message,
      stack: process.env.NODE_ENV === 'development' ? err.stack : undefined
    }
  });
});

// ========== Запуск сервера ==========
app.listen(PORT, () => {
  console.log(`🚀 Server running on port ${PORT}`);
  console.log(`   Health: http://localhost:${PORT}/api/health`);
});